import numpy as np


def get_loading_num(mu=0.0, sigma=1.0):
    return np.abs(np.ceil(np.random.normal(mu, sigma))) * np.random.randint(1, 4)


class Trucks:
    load_ratio = [2, 1, 0.5]  # 1 step あたりに積み込まれる A, B, C 別の本数の割合

    def __init__(self):
        # 各昇降機寄りの 1F～3F 全体で見た場合の平均と標準偏差をもとに積み込み本数を設定する
        self.load_items = {
            'A': get_loading_num(0.983, 2.247),
            'B': get_loading_num(1.064, 2.182),
            'C': get_loading_num(1.062, 1.997),
        }
        # assert self.is_loading(), 'Has No Loading Items.'
        if not self.is_loading():
            self.load_items = {
                'A': 3,
                'B': 3,
                'C': 3,
            }

    def load(self, platform=None):
        if platform == 'A':
            loaded_num = Trucks.load_ratio
        elif platform == 'C':
            loaded_num = reversed(Trucks.load_ratio)
        else:
            assert False, 'Select Any Platform.'

        for key, num in zip(self.load_items.keys(), loaded_num):
            self.load_items[key] = max(0, self.load_items[key] - num)

    def is_loading(self):
        return self.load_items['A'] != 0 or \
               self.load_items['B'] != 0 or \
               self.load_items['C'] != 0

    def __str__(self):
        return ' / '.join(['{}: {: >5.2f}'.format(key, self.load_items[key]) for key in self.load_items])

    def __repr__(self):
        return ' / '.join(['{}: {: >5.2f}'.format(key, self.load_items[key]) for key in self.load_items])
