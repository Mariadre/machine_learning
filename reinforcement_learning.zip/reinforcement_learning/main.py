from logistics_staff import Agent
from trucks import Trucks


NUM_STATES = 5       # 待機台数A, 待機台数C, A寄りの積み込み本数, B寄りの積み込み本数, C寄りの積み込み本数
NUM_ACTIONS = 2      # トラックの割り振り先に A を指定する, C を指定する

MAX_TRUCKS = 250     # 1 試行の最大トラック数
NUM_EPISODES = 1  # 最大試行回数

TRUCK_INTERVAL = 3  # 何 step ごとにトラックがやってくるか


# 実行環境のクラス
class Environment:

    def __init__(self):
        self.num_states = NUM_STATES    # 状態の数を設定
        self.num_actions = NUM_ACTIONS  # 行動の数を設定
        self.agent = Agent(self.num_states, self.num_actions)  # 環境内で行動する Agent を生成
        self.history = []  # 学習の履歴

    def run(self, verbose=False):

        for episode in range(NUM_EPISODES):

            # エピソード単位での初期化（日が変わる）
            steps = 0
            trucks = 0
            platform_A = []
            platform_C = []
            next_truck = None

            while True:
                steps += 1

                # ステップ単位での初期化
                action = None
                observation = []

                # トラックがやってきたとき
                if steps % TRUCK_INTERVAL == 0 and trucks < MAX_TRUCKS:
                    new_truck = Trucks() if next_truck is None else next_truck
                    observation = [
                        len(platform_A),
                        len(platform_C),
                        new_truck.load_items['A'],
                        new_truck.load_items['B'],
                        new_truck.load_items['C']
                    ]
                    action = self.agent.get_action(observation, episode)  # 行動を求める

                    if action:
                        platform_A.append(new_truck)
                        trucks += 1
                    else:
                        platform_C.append(new_truck)
                        trucks += 1

                # 各プラットフォーム毎のトラックの積み込み完了判定
                if platform_A:
                    t = platform_A[0]
                    t.load('A')
                    if not t.is_loading():
                        platform_A.pop(0)

                if platform_C:
                    t = platform_C[0]
                    t.load('C')
                    if not t.is_loading():
                        platform_C.pop(0)

                # 終了フラグ（一日分のトラックを捌き切れば終了）
                done = (trucks >= MAX_TRUCKS and not platform_A and not platform_C)

                # 報酬を与える
                reward = 0 if done else -1

                # 学習
                if steps % TRUCK_INTERVAL == 0 and trucks < MAX_TRUCKS:

                    # 行動の実行に伴う次状態を求める
                    if trucks < MAX_TRUCKS:
                        next_truck = Trucks()
                        observation_next = [
                            len(platform_A),
                            len(platform_C),
                            next_truck.load_items['A'],
                            next_truck.load_items['B'],
                            next_truck.load_items['C']
                        ]
                    else:
                        next_truck = None
                        observation_next = [
                            len(platform_A),
                            len(platform_C),
                            0,
                            0,
                            0
                        ]

                    # 次状態 observation_next を用いて,Q関数を更新する
                    self.agent.update_q_function(observation, action, reward, observation_next)

                # 学習ログの表示
                if done:
                    print('\nGood Work !')
                    print('*** Episode: {:4d}  Total Steps: {:4d} ***'.format(episode, steps))
                    self.history.append({'Episode': episode, 'Steps': steps})
                    break
                elif verbose:
                    print('\nEpisode: {:4d}  Step: {:4d}  Total Trucks: {:3d}'.format(episode, steps, trucks))
                    print('   Platform A   #trucks: {:2d}    |    Platform C   #trucks: {:2d}   '.
                          format(len(platform_A), len(platform_C)))
                    print('-' * 31 + '+' + '-' * 31)
                    for i in range(max(len(platform_A), len(platform_C))):
                        truck_A = platform_A[i] if i < len(platform_A) else ' ' * 30
                        truck_C = platform_C[i] if i < len(platform_C) else ' ' * 30
                        print('{} | {}'.format(truck_A, truck_C))


if __name__ == '__main__':
    from pprint import pprint

    env = Environment()
    env.run(verbose=False)
    pprint(env.history)

    # import pandas as pd
    # q_table = pd.DataFrame(env.agent.brain.q_table)
    # q_table.to_csv('result.csv', index=None)

    print('FINISH')
