import numpy as np


NUM_DIZITIZED = 6  # 各状態の離散値への分割数
GAMMA = 0.99       # 時間割引率
ETA = 0.5          # 学習係数


# エージェントクラス
class Agent:
    def __init__(self, num_states, num_actions):
        # 課題の状態と行動の数を設定
        self.num_states = num_states    # 状態数 5 を取得
        self.num_actions = num_actions  # 行動（A or C に割り振る）の 2 を取得
        self.brain = Brain(num_states, num_actions)  # エージェントの意思決定

    def update_q_function(self, observation, action, reward, observation_next):
        # Q 関数（Q テーブル）の更新
        self.brain.update_Qtable(observation, action, reward, observation_next)

    def get_action(self, observation, episode):
        # 行動の決定
        action = self.brain.decide_action(observation, episode)
        return action


# 意思決定ロジック（Q 学習）
class Brain:
    def __init__(self, num_states, num_actions):
        # 課題の状態と行動の数を設定
        self.num_states = num_states    # 状態数 5 を取得
        self.num_actions = num_actions  # 行動（A or C に割り振る）の 2 を取得
        # 状態を分割数^（5 変数）にデジタル変換した Q 関数（Q テーブル）を作成
        self.q_table = np.random.uniform(low=0, high=1, size=(NUM_DIZITIZED ** self.num_states, self.num_actions))
        # self.q_table = np.full(shape=(NUM_DIZITIZED ** self.num_states, self.num_actions), fill_value=0.5)

    def bins(self, clip_min, clip_max, num):
        # 観測した状態（連続値）を離散値にデジタル変換する
        return np.linspace(clip_min, clip_max, num + 1)[1:-1]

    def digitize_state(self, observation):
        # 観測した observation 状態を、離散値に変換する
        num_truck_A, num_truck_C, num_load_items_A, num_load_items_B, num_load_items_C = observation
        digitized = [
            np.digitize(num_truck_A, bins=self.bins(0, 30, NUM_DIZITIZED)),
            np.digitize(num_truck_C, bins=self.bins(0, 30, NUM_DIZITIZED)),
            np.digitize(num_load_items_A, bins=self.bins(0, 24, NUM_DIZITIZED)),
            np.digitize(num_load_items_B, bins=self.bins(0, 24, NUM_DIZITIZED)),
            np.digitize(num_load_items_C, bins=self.bins(0, 24, NUM_DIZITIZED))
        ]
        return sum([x * (NUM_DIZITIZED ** i) for i, x in enumerate(digitized)])

    def update_Qtable(self, observation, action, reward, observation_next):
        # Q テーブルを Q 学習により更新
        # 観測を離散化
        state = self.digitize_state(observation)
        state_next = self.digitize_state(observation_next)
        Max_Q_next = max(self.q_table[state_next][:])
        self.q_table[state, action] = self.q_table[state, action] + ETA * (
                    reward + GAMMA * Max_Q_next - self.q_table[state, action])

    def decide_action(self, observation, episode):
        # ε-greedy法で徐々に最適行動のみを採用する
        state = self.digitize_state(observation)
        epsilon = 0.5 * (1 / (episode + 1))

        if epsilon <= np.random.uniform(0, 1):
            action = np.argmax(self.q_table[state][:])   # Exploit
        else:
            action = np.random.choice(self.num_actions)  # Explore（0,1の行動をランダムに返す）
        return action


# if __name__ == '__main__':
#     from pprint import pprint
#     agent = Agent(5, 2)
#     print(agent.brain.q_table.shape)
#     pprint(agent.brain.q_table)
